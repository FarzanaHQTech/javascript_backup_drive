// 5! = 1*2*3*4*5 = 120

function factorial(number) {
  let result = 1;

  if (number === 0 || number === 1) {
    return 1;
  }

  for (let i = 1; i <= number; i++) {
    result = result * i;
  }

  return result;
}

const res = factorial(4);

console.log(res);
