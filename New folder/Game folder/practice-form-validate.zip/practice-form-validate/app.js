class FormValidate {
  handleSubmit(e) {
    // stop auto form reload
    e.preventDefault();
    //collect the input values
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;

    // error message
    const errors = document.querySelectorAll(".error-message");

    //email and phone pattern
    const emailPattern = /[a-z0-9]+@[a-z]+\.[a-z]/;
    const phonePattern = /^(\+8801|8801|01)[3-9]{1}[0-9]{8}$/;

    if (name == "" || email == "" || phone == "") {
      // je kono ekta field empty hole ei code block run hobe
      if (name == "") {
        errors[0].innerHTML = "Name is required!";
        document.getElementById("name").style.border = "1px solid red";
      }

      if (email == "") {
        errors[1].innerHTML = "Email is required!";
        document.getElementById("email").style.border = "1px solid red";
      } else {
        if (emailPattern.test(email)) {
          errors[1].innerHTML = "";
          document.getElementById("email").style.border = "1px solid #ccc";
        } else {
          errors[1].innerHTML = "Please Provide valid Email";

          document.getElementById("email").style.border = "1px solid red";
        }
      }

      if (phone == "") {
        errors[2].innerHTML = "Phone is required!";
        document.getElementById("phone").style.border = "1px solid red";
      } else {
        if (phonePattern.test(phone)) {
          errors[2].innerHTML = "";
          document.getElementById("phone").style.border = "1px solid #ccc";
        } else {
          errors[2].innerHTML = "Please provide valid BD number";
          document.getElementById("phone").style.border = "1px solid red";
        }
      }
    } else {
      // sob field e value thakle ei code run hobe

      // ager error thakle value bosanor por errror and border ager color hbe
      errors[0].innerHTML = "";
      document.getElementById("name").style.border = "1px solid #ccc";

      // email Validation with pattern
      if (emailPattern.test(email)) {
        errors[1].innerHTML = "";
        document.getElementById("email").style.border = "1px solid #ccc";
      } else {
        errors[1].innerHTML = "Please Provide valid Email";
        document.getElementById("email").style.border = "1px solid red";
      }

      // phone Validation with pattern
      if (phonePattern.test(phone)) {
        errors[2].innerHTML = "";
        document.getElementById("phone").style.border = "1px solid #ccc";
      } else {
        errors[2].innerHTML = "Please provide valid BD number";
        document.getElementById("phone").style.border = "1px solid red";
      }

      // jodi sob data thake tahole form submit hobe and success message dekhabe
      if (name && email && emailPattern.test(email) && phone && phonePattern.test(phone)) {
        document.getElementById("success").innerText = "Congrats!!";
        document.getElementById("name").value = "";
        document.getElementById("email").value = "";
        document.getElementById("phone").value = "";
      }

      // success message 3 second por clear hbe
      setTimeout(() => {
        document.getElementById("success").innerText = "";
      }, 3000);
    }
  }
}

const formValidattion = new FormValidate();
